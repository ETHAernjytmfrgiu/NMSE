/* --------------------------------------------------------------
   NMSE.Site - JavaScript
   • Animated star-field background (NMS spectral-class colours)
   • Auto-populates the download link from the latest GitHub
     Release so users get a direct .zip download without needing
     to navigate the GitHub Actions page (with CI fallback).
   • Configurable: update SITE_CONFIG
   -------------------------------------------------------------- */

// -- Portable configuration ------------------------------------ */
const SITE_CONFIG = {
  owner: "vectorcmdr",                                                         // GitHub user / org
  repo: "NMSE",                                                                // Repository name
  releaseTag: "latest",                                                        // LEGACY – no longer used (kept for reference)
  workflowFile: "build-nmse.yml",                                              // Workflow that produces the artifact (fallback)
  discordInvite: "https://discord.gg/WbDQKKP3us",                              // Discord invite link
  userdoc: "https://github.com/vectorcmdr/NMSE/blob/main/docs/user/README.md", // Path to user guide documentation in the repo
  devdoc: "https://github.com/vectorcmdr/NMSE/blob/main/docs/dev/README.md",   // Path to developer documentation in the repo
};

// -- Helpers ---------------------------------------------------- */
function timeAgo(dateString) {
  const seconds = Math.floor((Date.now() - new Date(dateString).getTime()) / 1000);
  const intervals = [
    { label: "year",   secs: 31536000 },
    { label: "month",  secs: 2592000 },
    { label: "day",    secs: 86400 },
    { label: "hour",   secs: 3600 },
    { label: "minute", secs: 60 },
  ];
  for (const { label, secs } of intervals) {
    const count = Math.floor(seconds / secs);
    if (count >= 1) return `${count} ${label}${count > 1 ? "s" : ""} ago`;
  }
  return "just now";
}

// -- Download link + build info --------------------------------- */
(function initDownloadLink() {
  const winLink = document.getElementById("download-link-windows");
  const linuxLink = document.getElementById("download-link-linux");
  const macLink = document.getElementById("download-link-macos");
  const note = document.getElementById("download-note");
  const buildInfo = document.getElementById("build-info");
  const buildNumber = document.getElementById("build-number");
  const buildUpdated = document.getElementById("build-updated");

  // SVG icons used for the download buttons (kept as strings so they can be
  // injected into button innerHTML and inherit currentColor)
  const WINDOWS_SVG = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d="M2 3.5L11 2v8H2z" fill="currentColor"/>
      <path d="M13 2l9-1v8h-9z" fill="currentColor" opacity="0.95"/>
      <path d="M2 13l9-1v8L2 20z" fill="currentColor" opacity="0.9"/>
      <path d="M13 12l9-1v8l-9 1z" fill="currentColor" opacity="0.85"/>
    </svg>`;

  const LINUX_SVG = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <title>Linux</title>
      <path d="M12.504 0c-.155 0-.315.008-.48.021-4.226.333-3.105 4.807-3.17 6.298-.076 1.092-.3 1.953-1.05 3.02-.885 1.051-2.127 2.75-2.716 4.521-.278.832-.41 1.684-.287 2.489a.424.424 0 00-.11.135c-.26.268-.45.6-.663.839-.199.199-.485.267-.797.4-.313.136-.658.269-.864.68-.09.189-.136.394-.132.602 0 .199.027.4.055.536.058.399.116.728.04.97-.249.68-.28 1.145-.106 1.484.174.334.535.47.94.601.81.2 1.91.135 2.774.6.926.466 1.866.67 2.616.47.526-.116.97-.464 1.208-.946.587-.003 1.23-.269 2.26-.334.699-.058 1.574.267 2.577.2.025.134.063.198.114.333l.003.003c.391.778 1.113 1.132 1.884 1.071.771-.06 1.592-.536 2.257-1.306.631-.765 1.683-1.084 2.378-1.503.348-.199.629-.469.649-.853.023-.4-.2-.811-.714-1.376v-.097l-.003-.003c-.17-.2-.25-.535-.338-.926-.085-.401-.182-.786-.492-1.046h-.003c-.059-.054-.123-.067-.188-.135a.357.357 0 00-.19-.064c.431-1.278.264-2.55-.173-3.694-.533-1.41-1.465-2.638-2.175-3.483-.796-1.005-1.576-1.957-1.56-3.368.026-2.152.236-6.133-3.544-6.139zm.529 3.405h.013c.213 0 .396.062.584.198.19.135.33.332.438.533.105.259.158.459.166.724 0-.02.006-.04.006-.06v.105a.086.086 0 01-.004-.021l-.004-.024a1.807 1.807 0 01-.15.706.953.953 0 01-.213.335.71.71 0 00-.088-.042c-.104-.045-.198-.064-.284-.133a1.312 1.312 0 00-.22-.066c.05-.06.146-.133.183-.198.053-.128.082-.264.088-.402v-.02a1.21 1.21 0 00-.061-.4c-.045-.134-.101-.2-.183-.333-.084-.066-.167-.132-.267-.132h-.016c-.093 0-.176.03-.262.132a.8.8 0 00-.205.334 1.18 1.18 0 00-.09.4v.019c.002.089.008.179.02.267-.193-.067-.438-.135-.607-.202a1.635 1.635 0 01-.018-.2v-.02a1.772 1.772 0 01.15-.768c.082-.22.232-.406.43-.533a.985.985 0 01.594-.2zm-2.962.059h.036c.142 0 .27.048.399.135.146.129.264.288.344.465.09.199.14.4.153.667v.004c.007.134.006.2-.002.266v.08c-.03.007-.056.018-.083.024-.152.055-.274.135-.393.2.012-.09.013-.18.003-.267v-.015c-.012-.133-.04-.2-.082-.333a.613.613 0 00-.166-.267.248.248 0 00-.183-.064h-.021c-.071.006-.13.04-.186.132a.552.552 0 00-.12.27.944.944 0 00-.023.33v.015c.012.135.037.2.08.334.046.134.098.2.166.268.01.009.02.018.034.024-.07.057-.117.07-.176.136a.304.304 0 01-.131.068 2.62 2.62 0 01-.275-.402 1.772 1.772 0 01-.155-.667 1.759 1.759 0 01.08-.668 1.43 1.43 0 01.283-.535c.128-.133.26-.2.418-.2zm1.37 1.706c.332 0 .733.065 1.216.399.293.2.523.269 1.052.468h.003c.255.136.405.266.478.399v-.131a.571.571 0 01.016.47c-.123.31-.516.643-1.063.842v.002c-.268.135-.501.333-.775.465-.276.135-.588.292-1.012.267a1.139 1.139 0 01-.448-.067 3.566 3.566 0 01-.322-.198c-.195-.135-.363-.332-.612-.465v-.005h-.005c-.4-.246-.616-.512-.686-.71-.07-.268-.005-.47.193-.6.224-.135.38-.271.483-.336.104-.074.143-.102.176-.131h.002v-.003c.169-.202.436-.47.839-.601.139-.036.294-.065.466-.065zm2.8 2.142c.358 1.417 1.196 3.475 1.735 4.473.286.534.855 1.659 1.102 3.024.156-.005.33.018.513.064.646-1.671-.546-3.467-1.089-3.966-.22-.2-.232-.335-.123-.335.59.534 1.365 1.572 1.646 2.757.13.535.16 1.104.021 1.67.067.028.135.06.205.067 1.032.534 1.413.938 1.23 1.537v-.043c-.06-.003-.12 0-.18 0h-.016c.151-.467-.182-.825-1.065-1.224-.915-.4-1.646-.336-1.77.465-.008.043-.013.066-.018.135-.068.023-.139.053-.209.064-.43.268-.662.669-.793 1.187-.13.533-.17 1.156-.205 1.869v.003c-.02.334-.17.838-.319 1.35-1.5 1.072-3.58 1.538-5.348.334a2.645 2.645 0 00-.402-.533 1.45 1.45 0 00-.275-.333c.182 0 .338-.03.465-.067a.615.615 0 00.314-.334c.108-.267 0-.697-.345-1.163-.345-.467-.931-.995-1.788-1.521-.63-.4-.986-.87-1.15-1.396-.165-.534-.143-1.085-.015-1.645.245-1.07.873-2.11 1.274-2.763.107-.065.037.135-.408.974-.396.751-1.14 2.497-.122 3.854a8.123 8.123 0 01.647-2.876c.564-1.278 1.743-3.504 1.836-5.268.048.036.217.135.289.202.218.133.38.333.59.465.21.201.477.335.876.335.039.003.075.006.11.006.412 0 .73-.134.997-.268.29-.134.52-.334.74-.4h.005c.467-.135.835-.402 1.044-.7zm2.185 8.958c.037.6.343 1.245.882 1.377.588.134 1.434-.333 1.791-.765l.211-.01c.315-.007.577.01.847.268l.003.003c.208.199.305.53.391.876.085.4.154.78.409 1.066.486.527.645.906.636 1.14l.003-.007v.018l-.003-.012c-.015.262-.185.396-.498.595-.63.401-1.746.712-2.457 1.57-.618.737-1.37 1.14-2.036 1.191-.664.053-1.237-.2-1.574-.898l-.005-.003c-.21-.4-.12-1.025.056-1.69.176-.668.428-1.344.463-1.897.037-.714.076-1.335.195-1.814.12-.465.308-.797.641-.984l.045-.022zm-10.814.049h.01c.053 0 .105.005.157.014.376.055.706.333 1.023.752l.91 1.664.003.003c.243.533.754 1.064 1.189 1.637.434.598.77 1.131.729 1.57v.006c-.057.744-.48 1.148-1.125 1.294-.645.135-1.52.002-2.395-.464-.968-.536-2.118-.469-2.857-.602-.369-.066-.61-.2-.723-.4-.11-.2-.113-.602.123-1.23v-.004l.002-.003c.117-.334.03-.752-.027-1.118-.055-.401-.083-.71.043-.94.16-.334.396-.4.69-.533.294-.135.64-.202.915-.47h.002v-.002c.256-.268.445-.601.668-.838.19-.201.38-.336.663-.336zm7.159-9.074c-.435.201-.945.535-1.488.535-.542 0-.97-.267-1.28-.466-.154-.134-.28-.268-.373-.335-.164-.134-.144-.333-.074-.333.109.016.129.134.199.2.096.066.215.2.36.333.292.2.68.467 1.167.467.485 0 1.053-.267 1.398-.466.195-.135.445-.334.648-.467.156-.136.149-.267.279-.267.128.016.034.134-.147.332a8.097 8.097 0 01-.69.468zm-1.082-1.583V5.64c-.006-.02.013-.042.029-.05.074-.043.18-.027.26.004.063 0 .16.067.15.135-.006.049-.085.066-.135.066-.055 0-.092-.043-.141-.068-.052-.018-.146-.008-.163-.065zm-.551 0c-.02.058-.113.049-.166.066-.047.025-.086.068-.14.068-.05 0-.13-.02-.136-.068-.01-.066.088-.133.15-.133.08-.031.184-.047.259-.005.019.009.036.03.03.05v.02h.003z" fill="currentColor"/>
    </svg>`;

  const MACOS_SVG = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d="M16.04 1.5c.28-1.06.8-2.08 1.54-2.5-1.44-.17-3.03.9-3.8 2.03-.78 1.16-.92 2.46-.53 3.78 1.06.04 2.12-.54 2.79-1.3zM21.95 7.25c-1.14-1.33-2.66-2.01-4.07-2.04-1.68-.04-3.26 1.06-4.12 1.06-.86 0-2.3-1.03-3.78-1.01-2.17.02-4.17 1.27-5.28 3.24-2.27 3.98-.58 9.88 1.62 13.14 1.08 1.47 2.35 3.12 4.03 3.06 1.6-.06 2.2-1.04 4.13-1.04 1.94 0 2.46 1.04 4.06 1.01 1.68-.03 2.74-1.49 3.81-2.99 1.22-1.76 1.73-3.47 1.76-3.56-.04-.01-3.4-1.31-3.45-5.2-.04-3.5 2.86-5.19 2.98-5.28-.02-.02-2.86-1.1-2.94-4.2z" fill="currentColor"/>
    </svg>`;

  const WINDOWS_BUTTON_HTML = WINDOWS_SVG + ' <b>Download</b>';
  const LINUX_BUTTON_HTML = LINUX_SVG + ' <b>Download</b>';
  const MACOS_BUTTON_HTML = MACOS_SVG + ' <b>Download</b>';

  function setBtn(link, html, href, tooltipText) {
    if (!link) return;
    link.href = href;
    link.innerHTML = html;
    link.title = "";
    if (tooltipText) {
      link.dataset.tooltip = tooltipText;
      link.classList.add("btn-tooltip");
    } else {
      link.removeAttribute("data-tooltip");
      link.classList.remove("btn-tooltip");
    }
  }

  // Fallback: send users to the Actions page if the release API fails
  const actionsUrl =
    `https://github.com/${SITE_CONFIG.owner}/${SITE_CONFIG.repo}/actions/workflows/${SITE_CONFIG.workflowFile}`;
  const fallbackNote = "Opens the build workflow page \u2013 download the artifact from there.";

  // Default to the Actions page so buttons are never dead links
  setBtn(winLink, WINDOWS_BUTTON_HTML, actionsUrl, "");
  setBtn(linuxLink, LINUX_BUTTON_HTML, actionsUrl, "");
  setBtn(macLink, MACOS_BUTTON_HTML, actionsUrl, "");

  // Fetch the latest GitHub Release (created by CI with a versioned tag e.g. v1.2.3)
  const apiUrl =
    `https://api.github.com/repos/${SITE_CONFIG.owner}/${SITE_CONFIG.repo}/releases/latest`;

  fetch(apiUrl)
    .then(res => {
      if (!res.ok) throw new Error(res.status);
      return res.json();
    })
    .then(release => {
      if (release.assets && release.assets.length > 0) {
        // Prefer a .zip for Windows and an .AppImage for Linux (case-insensitive)
        const assets = release.assets;
        const zipAsset = assets.find(a => /\.zip$/i.test(a.name) || /\.zip$/i.test(a.browser_download_url));
        const appImageAsset = assets.find(a => /\.appimage$/i.test(a.name) || /\.appimage$/i.test(a.browser_download_url));

        if (winLink) {
          if (zipAsset) {
            winLink.href = zipAsset.browser_download_url;
            winLink.innerHTML = WINDOWS_BUTTON_HTML;
            winLink.title = zipAsset.name;
          } else {
            winLink.href = actionsUrl;
            winLink.innerHTML = WINDOWS_BUTTON_HTML;
            winLink.title = "Uh oh! Something went wrong. No Windows ZIP available in this release.";
          }
        }

        if (linuxLink) {
          if (appImageAsset) {
            setBtn(linuxLink, LINUX_BUTTON_HTML, appImageAsset.browser_download_url, "");
            linuxLink.title = appImageAsset.name;
          } else {
            setBtn(linuxLink, LINUX_BUTTON_HTML, actionsUrl, "No Linux AppImage available in this release");
          }
        }

        if (macLink) {
          const dmgAsset = assets.find(a => /\.dmg$/i.test(a.name) || /\.dmg$/i.test(a.browser_download_url));
          if (dmgAsset) {
            setBtn(macLink, MACOS_BUTTON_HTML, dmgAsset.browser_download_url, "");
            macLink.title = dmgAsset.name;
          } else {
            setBtn(macLink, MACOS_BUTTON_HTML, actionsUrl, "No macOS DMG available in this release");
          }
        }

        // Show the version from the release name or tag (e.g. "NMSE v1.2.3" or "v1.2.3")
        buildNumber.textContent = release.name || release.tag_name;
        buildUpdated.textContent = `updated ${timeAgo(release.published_at)}`;
        buildInfo.hidden = false;
        note.textContent = "Click download above for your OS.";
      } else {
        note.textContent = "No builds available yet.";
      }
    })
    .catch(() => {
      // Release not found - fall back to Actions page
      setBtn(winLink, WINDOWS_BUTTON_HTML, actionsUrl, fallbackNote);
      setBtn(linuxLink, LINUX_BUTTON_HTML, actionsUrl, fallbackNote);
      setBtn(macLink, MACOS_BUTTON_HTML, actionsUrl, fallbackNote);
      note.textContent = fallbackNote;
    });
})();

// -- Discord link ----------------------------------------------- */
(function initDiscordLink() {
  const link = document.getElementById("discord-link");
  link.href = SITE_CONFIG.discordInvite;
})();

// -- Developer links -------------------------------------------- */
(function initDevLinks() {
  const ghLink = document.getElementById("dev-github-link");
  const sponsorLink = document.getElementById("dev-sponsor-link");
  const repoLink = document.getElementById("dev-like-link");
  const issueLink = document.getElementById("dev-issue-link");
  const footerLink = document.getElementById("dev-github-link-footer");
  const docsUserLink = document.getElementById("docs-user-link");
  const docsDevLink = document.getElementById("docs-dev-link");

  ghLink.href = `https://github.com/${SITE_CONFIG.owner}`;
  ghLink.textContent = SITE_CONFIG.owner;

  sponsorLink.href = `https://github.com/sponsors/${SITE_CONFIG.owner}`;

  repoLink.href = `https://github.com/${SITE_CONFIG.owner}/${SITE_CONFIG.repo}`;

  issueLink.href = `https://github.com/${SITE_CONFIG.owner}/${SITE_CONFIG.repo}/issues`;

  footerLink.href = `https://github.com/${SITE_CONFIG.owner}`;
  footerLink.textContent = SITE_CONFIG.owner;

  docsUserLink.href = `${SITE_CONFIG.userdoc}`;
  docsDevLink.href = `${SITE_CONFIG.devdoc}`;
})();

// -- Star-field (NMS spectral-class colours) -------------------- */
(function initStarfield() {
  const canvas = document.getElementById("starfield");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  // NMS stellar spectral-class colours
  const STAR_COLOURS = [
    [107, 136, 255],  // O - Blue
    [160, 196, 255],  // B - Blue-white
    [240, 240, 255],  // A - White
    [255, 248, 224],  // F - Yellow-white
    [255, 229, 102],  // G - Yellow
    [255, 170,  51],  // K - Orange
    [255, 102,  51],  // M - Red
    [ 51, 255, 153],  // E - Green (exotic)
  ];

  let width, height, stars;
  const STAR_COUNT = 260;
  const MAX_DEPTH = 600;
  const STAR_SPEED = 0.15;

  function resize() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }

  function createStars() {
    stars = Array.from({ length: STAR_COUNT }, () => ({
      x: Math.random() * width - width / 2,
      y: Math.random() * height - height / 2,
      z: Math.random() * MAX_DEPTH,
      colour: STAR_COLOURS[Math.floor(Math.random() * STAR_COLOURS.length)],
    }));
  }

  function draw() {
    ctx.clearRect(0, 0, width, height);

    for (const s of stars) {
      s.z -= STAR_SPEED;
      if (s.z <= 0) {
        s.x = Math.random() * width - width / 2;
        s.y = Math.random() * height - height / 2;
        s.z = MAX_DEPTH;
        s.colour = STAR_COLOURS[Math.floor(Math.random() * STAR_COLOURS.length)];
      }

      const scale = 128 / s.z;
      const sx = s.x * scale + width / 2;
      const sy = s.y * scale + height / 2;
      const r = Math.max(0, 1.2 - s.z / MAX_DEPTH) * 1.5;
      const alpha = Math.max(0, 1 - s.z / MAX_DEPTH);

      const [cr, cg, cb] = s.colour;
      ctx.beginPath();
      ctx.arc(sx, sy, r, 0, Math.PI * 2);
      ctx.shadowBlur = r * 8;
      ctx.shadowColor = `rgba(${cr},${cg},${cb},${(alpha * 2).toFixed(2)})`;
      ctx.fillStyle = `rgba(${cr},${cg},${cb},${(alpha * 1.6).toFixed(2)})`;
      ctx.fill();
    }

    ctx.shadowBlur = 0;
    ctx.shadowColor = "transparent";

    requestAnimationFrame(draw);
  }

  window.addEventListener("resize", () => {
    resize();
    createStars();
  });

  resize();
  createStars();
  draw();
})();
